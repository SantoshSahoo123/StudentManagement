package com.student.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.StudentEntityDao;
import com.student.model.StudentDto;
import com.student.repo.StudentRepo;

@Service
public class StudentManagementServiceImpl implements StudentManagementService {
	
	@Autowired
	private StudentRepo repo;

	@Override
	public List<StudentEntityDao> processStudent(List<StudentDto> students) {
		List<StudentEntityDao> saveAll = null;
		if(students != null) {
		List<StudentEntityDao> studentEntityForPersist = prepareStudentEntityForPersist(students);
		saveAll = repo.saveAll(studentEntityForPersist);
		System.out.println(studentEntityForPersist.toString());
		} else {
			return null;
		}
		
		return saveAll;

	}
	
	@Override
	public List<StudentDto> findAllStudents() {
		List<StudentEntityDao> all = repo.findAll();
		return prepareStudentDto(all);
	}
	
	@Override
	public List<StudentDto> findStudentsBetweenAge(int startAge, int endAge) {
		List<StudentEntityDao> byAgeBetween = repo.findByAgeBetween(startAge, endAge);
		return prepareStudentDto(byAgeBetween);
	}
	
	
	// prepare the input json date to the list of entity object to store in data
	private List<StudentEntityDao> prepareStudentEntityForPersist(List<StudentDto> dto){
		List<StudentEntityDao> listStudentEntity = new ArrayList<>();
		List<String> studentsName = new ArrayList<>();
		
		// this is to gather the students name for checking duplicate record and insert unique students.
		for(StudentDto indivisualStudent : dto) {
			studentsName.add(indivisualStudent.getName());	
		}
		
		List<String> filterStudents = filterStudents(studentsName);
		Integer maxId = findMaxId();
		
		for(StudentDto indivisualStudent : dto) {
			if(!filterStudents.contains(indivisualStudent.getName())) {
			LocalDate dobInfo = findDayMonthYearFromDate(indivisualStudent.getDob());
			StudentEntityDao dao = new StudentEntityDao();
			dao.setId(maxId + 1);
			dao.setName(indivisualStudent.getName());
			dao.setAge(findAge(indivisualStudent.getDob()));
			dao.setBirthDay(dobInfo.getDayOfMonth());
			dao.setBirthMonth(dobInfo.getMonthValue());
			dao.setBirthYear(dobInfo.getYear());
			listStudentEntity.add(dao);
			maxId+=1;
			}
		}
		
		return listStudentEntity;
	}
	
	// prepare the actual date object from the string formated date.
	private LocalDate findDayMonthYearFromDate(String dob) {
		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate studentDate = LocalDate.parse(dob,ofPattern);
		
		return studentDate;
	}
	
	// find age from string formated date
	private Integer findAge(String dob) {
		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate studentAge = LocalDate.parse(dob,ofPattern);
		LocalDate currentDate = LocalDate.now();
		
		return Period.between(studentAge, currentDate).getYears();
	}
	
	// convert the db record into the student dto w.r.t dob
	private List<StudentDto> prepareStudentDto(List<StudentEntityDao> dao){
		List<StudentDto> allStudentDto = new ArrayList<>();
		for(StudentEntityDao student : dao) {
			StudentDto dto = new StudentDto();
			dto.setName(student.getName());
			dto.setDob(student.getBirthDay()+"-"+student.getBirthMonth()+"-"+student.getBirthYear());
			dto.setAge(student.getAge());
			allStudentDto.add(dto);
		}
		return allStudentDto;
	}
	
	// method for collect the max id from the mongo to use as unique for new students.
	private Integer findMaxId() {
		StudentEntityDao topByOrderByIdDesc = repo.findTopByOrderByIdDesc();
		if(topByOrderByIdDesc != null) {
			return topByOrderByIdDesc.getId();
		} else {
			return 0;
		}
	}

	private List<String> filterStudents(List<String> string){
		List<StudentEntityDao> byNameIn = repo.findByNameIn(string);
		string.clear();
		for(StudentEntityDao student : byNameIn) {
			string.add(student.getName());
		}
		return string;
	}

	

}








