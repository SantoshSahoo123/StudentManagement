package com.student.service;

import java.util.List;

import com.student.entity.StudentEntityDao;
import com.student.model.StudentDto;

public interface StudentManagementService {
	
	public List<StudentEntityDao> processStudent(List<StudentDto> students);
	public List<StudentDto> findAllStudents();
	public List<StudentDto> findStudentsBetweenAge(int startDate, int endDate);

}
