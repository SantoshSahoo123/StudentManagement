package com.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.entity.StudentEntityDao;
import com.student.model.StudentDto;
import com.student.service.StudentManagementService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentManagementService service;

	@PostMapping("/save/students")
	public ResponseEntity<Object> persistStudents(@RequestBody @Validated List<StudentDto> dto) {
		List<StudentEntityDao> processStudent = service.processStudent(dto);
		if (processStudent != null) {
			return new ResponseEntity(processStudent, HttpStatus.OK);
		} else {
			return new ResponseEntity("object failed to insert !!", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/find/all")
	public ResponseEntity<Object> fetchAllStudents() {
		List<StudentDto> allStudents = service.findAllStudents();

		if (allStudents != null) {
			return new ResponseEntity(allStudents, HttpStatus.OK);
		} else {
			return new ResponseEntity("no record found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/find/age/between/{start}/{end}")
	public ResponseEntity<Object> getStudentBetweenAge(@PathVariable int start, @PathVariable int end) {
		List<StudentDto> allStudentBetweenAge = service.findStudentsBetweenAge(start, end);
		if (allStudentBetweenAge != null) {
			return new ResponseEntity(allStudentBetweenAge, HttpStatus.OK);
		} else {
			return new ResponseEntity("no record found", HttpStatus.NOT_FOUND);
		}
	}

}
